export function Home() {
  return <h1>Home</h1>
}
